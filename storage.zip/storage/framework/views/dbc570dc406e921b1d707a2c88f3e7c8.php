<?php echo $__env->make('view.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="plant-categories-section">
    <div class="plant-categories-container">

        <div class="categories-carousel-container">
            <!-- Carousel -->
            <div class="plant-categories-carousel" id="plantCategoriesCarousel">
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="plant-category-item">
                    <a href="<?php echo e(route('category.show', $category->slug ?? $category->id)); ?>" class="plant-category-card">
                        <div class="category-image-container">
                            <?php if($category->badge_type): ?>
                                <span class="category-badge badge-<?php echo e($category->badge_type); ?>"><?php echo e(\Illuminate\Support\Str::upper($category->badge_type)); ?></span>
                            <?php endif; ?>
                            <div class="plant-category-image">
                                <?php if($category->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $category->image)); ?>" alt="<?php echo e($category->name); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/category-placeholder.jpg')); ?>" alt="<?php echo e($category->name); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="plant-category-content">
                            <h3 class="plant-category-name"><?php echo e($category->name); ?></h3>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="plant-category-item">
                    <p class="text-center w-100">No categories available</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- vertical menu and slider -->
<div id="home_vertical_menu" class="menu_slider ">
    <div class="row ">
        <div class="col-lg-12 col-md-12 main_slider">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <?php if($sliders->count() > 0): ?>
                <ol class="carousel-indicators">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($index); ?>" class="<?php echo e($index === 0 ? 'active' : ''); ?>"></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
                <div class="carousel-inner">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                        <img src="<?php echo e(asset('storage/' . $slider->image)); ?>" class="d-block w-100 img-fluid" alt="<?php echo e($slider->title); ?>">
                        <div class="carousel-caption container silder_text">
                            <?php if($slider->subtitle): ?><p class="arrival"><?php echo e($slider->subtitle); ?></p><?php endif; ?>
                            <?php if($slider->title): ?><h5 class="headding"><?php echo e($slider->title); ?></h5><?php endif; ?>
                            <?php if($slider->button_link && $slider->button_text): ?><a href="<?php echo e($slider->button_link); ?>" type="btn" class="shop-now"><?php echo e($slider->button_text); ?></a><?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php else: ?>
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="<?php echo e(asset('uploads/img2/slider/11.png')); ?>" class="d-block w-100 img-fluid" alt="s1">
                        <div class="carousel-caption container silder_text">
                            <p class="arrival">Complete Care for Every Plant</p>
                            <h5 class="headding">From Soil to<br>Bloom Naturally</h5>
                            <a type="btn" class="shop-now">Shop Now</a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button"
                    data-slide="prev"></a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button"
                    data-slide="next"></a>
            </div>
        </div>
    </div>
</div>
<!-- vertical menu and slider end -->

<!-- services -->
<div class="container-fluid">
    <div class="main_services">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-12 m_service ">
                <ul class="bg-white service service-1 rounded text-center  animate__animated animate__fadeInUp"
                    data-wow-duration="0.8s" data-wow-delay="0.1s">
                    <li class="ser-svg d-lg-inline-block d-md-block  align-middle">
                        <span class="icon-image"></span>
                    </li>
                    <li class="ser-t d-lg-inline-block d-md-block  align-middle text-left">
                        <h6>Fast Delivery</h6>
                        <span class="mb-0 text-muted">Fast shipping on all orders</span>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-12 m_service">
                <ul class="bg-white service service-2 rounded text-center  animate__animated animate__fadeInUp"
                    data-wow-duration="0.8s" data-wow-delay="0.2s">
                    <li class="ser-svg d-lg-inline-block d-md-block align-middle">
                        <span class="icon-image"></span>
                    </li>
                    <li class="ser-t d-lg-inline-block d-md-block align-middle text-left">
                        <h6>secure payment</h6>
                        <span class="mb-0 text-muted">100% Secure Payment</span>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-12 m_service">
                <ul class="bg-white service service-3 rounded text-center  animate__animated animate__fadeInUp"
                    data-wow-duration="0.8s" data-wow-delay="0.3s">
                    <li class="ser-svg d-lg-inline-block d-md-block align-middle">
                        <span class="icon-image"></span>
                    </li>
                    <li class="ser-t d-lg-inline-block d-md-block align-middle  text-left">
                        <h6>Easy Returns</h6>
                        <span class="mb-0 text-muted">30-Day Return Policy</span>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-12 m_service">
                <ul class="bg-white service service-4 rounded text-center  animate__animated animate__fadeInUp"
                    data-wow-duration="0.8s" data-wow-delay="0.4s">
                    <li class="ser-svg d-lg-inline-block d-md-block align-middle">
                        <span class="icon-image"></span>
                    </li>
                    <li class="ser-t d-lg-inline-block d-md-block align-middle  text-left">
                        <h6>Quality Guarantee</h6>
                        <span class="mb-0 text-muted">Premium Quality Products</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- services end -->


<?php
if (!function_exists('renderProductCard')) {
    function renderProductCard($product) {
        $imgSrc = $product->image ? asset('storage/' . $product->image) : asset('assets/images/product/product1.jpg');
        $slug = $product->slug ?? $product->id;
        $price = number_format($product->price ?? 0, 2);
        $salePrice = ($product->sale_price && $product->sale_price > 0 && $product->sale_price < $product->price) ? number_format($product->sale_price, 2) : null;
        $discount = $product->discount_percentage ?? null;

        return '
        <div class="swiper-slide">
            <div class="product-card">
                <div class="product-image-container">
                    <a href="'.route('product.show', $slug).'">
                        <img src="'.$imgSrc.'" alt="'.$product->name.'" class="product-image main-image">
                        <img src="'.$imgSrc.'" alt="'.$product->name.'" class="product-image hover-image">
                        '.($salePrice && $discount > 0 ? '<span class="discount-badge">'.$discount.'% OFF</span>' : '').'
                    </a>
                </div>
                <div class="product-info">
                    <h3 class="product-title">'.$product->name.'</h3>
                    <div class="product-price">
                        '.($salePrice 
                            ? '<span class="original-price">₹'.$price.'</span><span class="current-price">₹'.$salePrice.'</span>' 
                            : '<span class="current-price">₹'.$price.'</span>').'
                    </div>
                    <div class="product-actions">
                        <button class="btn btn-primary" data-tooltip="Buy Now">
                            <span class="btn-text">Buy Now</span><i class="btn-icon fas fa-shopping-bag"></i>
                        </button>
                        <form class="add-to-cart-form d-inline-block text-white" method="POST" action="'.route('cart.add', $product->id).'" style="display:inline;">
                            '.csrf_field().'
                            <button type="submit" class="btn btn-secondary" data-tooltip="Add to Cart">
                                <span class="btn-text">Add to Cart</span><i class="btn-icon fas fa-shopping-cart"></i>
                            </button>
                        </form>
                        <form class="d-inline-block" method="POST" action="'.route('wishlist.add', $product->id).'" style="display:inline;">
                            '.csrf_field().'
                            <button type="submit" class="btn btn-wishlist" data-tooltip="Wishlist">
                                <i class="far fa-heart"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>';
    }
}
?>

<!-- Section 1: New Arrivals -->
<section class="bg-white-section">
    <div class="container-fluid px-4">
        <div class="section-title">
            <h2>New Arrivals</h2>
            <div class="title-link">
                <a href="<?php echo e(url('categories')); ?>">More <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <div class="swiper product-swiper">
            <div class="swiper-wrapper">
                <?php $__empty_1 = true; $__currentLoopData = $newArrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo renderProductCard($product); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="swiper-slide"><p class="text-center w-100">No products found</p></div>
                <?php endif; ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>

<!-- Section 2: Garden Products -->
<section class="bg-light-section">
    <div class="container-fluid px-4">
        <div class="section-title">
            <h2>Garden Products</h2>
            <div class="title-link">
                <a href="<?php echo e(url('categories')); ?>">More <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <div class="swiper product-swiper">
            <div class="swiper-wrapper">
                <?php $__empty_1 = true; $__currentLoopData = $gardenProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo renderProductCard($product); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="swiper-slide"><p class="text-center w-100">No products found</p></div>
                <?php endif; ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>

<section class="ad-banner">
    <div class="banner-content">
        <h1 class="big-title">Fresh Plant-Based Goodness</h1>
        <p class="small-title">Discover our organic, sustainable products for a healthier lifestyle</p>
        <a href="<?php echo e(url('categories')); ?>" class="contact-btn">Shop Now <i class="fas fa-leaf"></i></a>
    </div>
</section>

<!-- Section 3: Planted Aquarium Products -->
<section class="bg-white-section">
    <div class="container-fluid px-4">
        <div class="section-title">
            <h2>Planted Aquarium Products</h2>
            <div class="title-link">
                <a href="<?php echo e(url('categories')); ?>">More <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <div class="swiper product-swiper">
            <div class="swiper-wrapper">
                <?php $__empty_1 = true; $__currentLoopData = $aquariumProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo renderProductCard($product); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="swiper-slide"><p class="text-center w-100">No products found</p></div>
                <?php endif; ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>

<!-- Section 4: Natural Products -->
<section class="bg-light-section">
    <div class="container-fluid px-4">
        <div class="section-title">
            <h2>Natural Products</h2>
            <div class="title-link">
                <a href="<?php echo e(url('categories')); ?>">More <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <div class="swiper product-swiper">
            <div class="swiper-wrapper">
                <?php $__empty_1 = true; $__currentLoopData = $naturalProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo renderProductCard($product); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="swiper-slide"><p class="text-center w-100">No products found</p></div>
                <?php endif; ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>

<!---------------------------------------------------------- testimonials ------------------------------------------------------->
<div class="reviews-carousel">
    <div class="carousel-header">
        <h2 class="section-title1 text-center">Trusted by thousands</h2>
        <div class="see-more">See more reviews</div>
    </div>

    <!-- Swiper -->
    <div class="swiper testimonial-swiper">
        <div class="swiper-wrapper">
            <?php $__empty_1 = true; $__currentLoopData = $testimonials ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="swiper-slide">
                    <div class="review-card">
                        <div class="reviewer-info">
                            <div class="reviewer-name"><?php echo e($testimonial->name); ?></div>
                            <div class="verified-badge">
                                <i class="fas fa-badge-check"></i>
                                <span>Verified Buyer</span>
                            </div>
                        </div>
                        <div class="review-date"><?php echo e($testimonial->created_at->format('m/d/y')); ?></div>
                        <div class="star-rating">
                            <?php for($i=1; $i<=5; $i++): ?>
                                <i class="fas fa-star <?php echo e($i <= ($testimonial->rating ?? 5) ? 'star' : 'text-muted'); ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <?php if($testimonial->title): ?>
                            <h3 class="review-title"><?php echo e($testimonial->title); ?></h3>
                        <?php endif; ?>
                        <p class="review-content">
                            <?php echo e($testimonial->message); ?>

                        </p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <!-- Default Hardcoded Examples if no DB testimonials -->
                <div class="swiper-slide">
                    <div class="review-card">
                        <div class="reviewer-info">
                            <div class="reviewer-name">Emma J.</div>
                            <div class="verified-badge">
                                <i class="fas fa-badge-check"></i>
                                <span>Verified Buyer</span>
                            </div>
                        </div>
                        <div class="review-date">11/07/25</div>
                        <div class="star-rating">
                            <i class="fas fa-star star"></i><i class="fas fa-star star"></i><i class="fas fa-star star"></i><i class="fas fa-star star"></i><i class="fas fa-star star"></i>
                        </div>
                        <h3 class="review-title">Very happy with all of</h3>
                        <p class="review-content">
                            Very happy with all of my new plants. Prices were good, delivery was fast, and the plants are gorgeous.
                        </p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Navigation -->
    <div class="carousel-nav">
        <div class="nav-btn swiper-button-prev1">
            <i class="fas fa-chevron-left"></i>
        </div>
        <div class="nav-btn swiper-button-next1">
            <i class="fas fa-chevron-right"></i>
        </div>
    </div>
</div>

<section class="bg-light-section">
    <div class="container-fluid px-4">
        <div class="section-title">
            <h2>Blogs</h2>
            <div class="title-link">
                <a href="<?php echo e(url('blogs')); ?>">More <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <div class="col-12">
            <div class="blog-grid">
                <div class="row g-4">
                    <?php $__empty_1 = true; $__currentLoopData = $blogs ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-card">
                            <div class="blog-card-image">
                                <?php if($blog->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/product/product11.jpg')); ?>" alt="<?php echo e($blog->title); ?>">
                                <?php endif; ?>
                                <span class="blog-card-category"><?php echo e($blog->category->name ?? 'General'); ?></span>
                            </div>
                            <div class="blog-card-content">
                                <div class="blog-card-date"><?php echo e($blog->created_at->format('M d, Y')); ?></div>
                                <h3 class="blog-card-title"><?php echo e($blog->title); ?></h3>
                                <p class="blog-card-excerpt">
                                    <?php echo e(\Illuminate\Support\Str::limit(strip_tags($blog->content), 100)); ?>

                                </p>
                                <div class="blog-card-footer">
                                    <span class="blog-card-author"><?php echo e($blog->author_name ?? 'Admin'); ?></span>
                                    <a href="#" class="read-more-link">Read →</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- Default Blog Cards -->
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-card">
                            <div class="blog-card-image">
                                <img src="<?php echo e(asset('assets/images/product/product11.jpg')); ?>" alt="Indoor plant care">
                                <span class="blog-card-category">Plant Care</span>
                            </div>
                            <div class="blog-card-content">
                                <div class="blog-card-date">Nov 15, 2024</div>
                                <h3 class="blog-card-title">10 Essential Tips to Keep Indoor Plants Healthy</h3>
                                <p class="blog-card-excerpt">
                                    Learn the fundamental watering, lighting, and soil requirements that help indoor plants grow stronger and greener.
                                </p>
                                <div class="blog-card-footer">
                                    <span class="blog-card-author">Sophia Green</span>
                                    <a href="#" class="read-more-link">Read →</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('view.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- Notification after Add to Cart -->
<div id="cart-alert-container" style="position: fixed; z-index: 99999; left: 50%; transform: translateX(-50%); top: 20px; display: none;">
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="cart-added-alert" style="min-width: 250px;">
        Item added with success!
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.add-to-cart-form, .wishlist-form').forEach(function(form) {
        form.addEventListener('submit', function(event) {
            setTimeout(function() {
                var alertContainer = document.getElementById('cart-alert-container');
                if (alertContainer) {
                    alertContainer.style.display = 'block';
                    setTimeout(function() {
                        alertContainer.style.display = 'none';
                    }, 2000);
                }
            }, 200);
        });
    });
});
</script><?php /**PATH D:\xampp\htdocs\plantsware\resources\views/view/index.blade.php ENDPATH**/ ?>