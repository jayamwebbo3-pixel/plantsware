<?php $__env->startSection('title', 'Subcategories - ' . $category->name); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <a href="<?php echo e(route('admin.products.management')); ?>" class="text-decoration-none">
        ← Back to Categories
    </a>
</div>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Subcategories in "<?php echo e($category->name); ?>"</h2>
    <a href="<?php echo e(route('admin.categories.subcategories.create', ['category' => $category->id])); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add Subcategory
    </a>
</div>

<div class="card">
    <div class="card-body">

        
        <div class="row mb-3">
            <div class="col-md-6">
                <form action="<?php echo e(route('admin.categories.subcategories', ['category' => $category->id])); ?>" method="GET">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search subcategories..."
                               value="<?php echo e(request('search')); ?>">
                        <button class="btn btn-outline-secondary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
            <div class="col-md-6 text-end">
                <form action="<?php echo e(route('admin.categories.subcategories', ['category' => $category->id])); ?>" method="GET" class="d-inline">
                    <label class="me-2">Show</label>
                    <select name="per_page" onchange="this.form.submit()" class="form-select d-inline w-auto">
                        <option value="10" <?php echo e(request('per_page', 20) == 10 ? 'selected' : ''); ?>>10</option>
                        <option value="25" <?php echo e(request('per_page', 20) == 25 ? 'selected' : ''); ?>>25</option>
                        <option value="50" <?php echo e(request('per_page', 20) == 50 ? 'selected' : ''); ?>>50</option>
                        <option value="100" <?php echo e(request('per_page', 20) == 100 ? 'selected' : ''); ?>>100</option>
                    </select>
                    <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                    <input type="hidden" name="sort" value="<?php echo e(request('sort', 'sort_order')); ?>">
                    <input type="hidden" name="direction" value="<?php echo e(request('direction', 'asc')); ?>">
                </form>
            </div>
        </div>

        <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>
                        <a href="<?php echo e(route('admin.categories.subcategories', [
                                'category' => $category->id,
                                'sort' => 'name',
                                'direction' => request('sort') == 'name' && request('direction') == 'asc' ? 'desc' : 'asc',
                                'search' => request('search'),
                                'per_page' => request('per_page', 20),
                            ])); ?>" class="text-dark text-decoration-none">
                            Name
                            <?php if(request('sort') == 'name'): ?>
                                <i class="fas fa-sort-<?php echo e(request('direction') == 'asc' ? 'up' : 'down'); ?> ms-1"></i>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="<?php echo e(route('admin.categories.subcategories', [
                                'category' => $category->id,
                                'sort' => 'sort_order',
                                'direction' => request('sort') == 'sort_order' && request('direction') == 'asc' ? 'desc' : 'asc',
                                'search' => request('search'),
                                'per_page' => request('per_page', 20),
                            ])); ?>" class="text-dark text-decoration-none">
                            Sort Order
                            <?php if(request('sort') == 'sort_order'): ?>
                                <i class="fas fa-sort-<?php echo e(request('direction') == 'asc' ? 'up' : 'down'); ?> ms-1"></i>
                            <?php endif; ?>
                        </a>
                    </th>
                    
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($subcategory->image): ?>
                            <img src="<?php echo e(asset('storage/' . $subcategory->image)); ?>" style="width: 60px; height: 60px; object-fit: cover;">
                        <?php else: ?>
                            <div class="bg-light border d-flex align-items-center justify-content-center" style="width: 60px; height: 60px; border-radius: 8px;">
                                <i class="fas fa-image text-muted"></i>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td><strong><?php echo e($subcategory->name); ?></strong></td>
                    <td><?php echo e($subcategory->sort_order); ?></td>
                    
                    <td>
                        <a href="<?php echo e(route('admin.subcategories.products', $subcategory)); ?>" class="btn btn-sm btn-outline-primary">
                            View Products &rarr;
                        </a>
                        <a href="<?php echo e(route('admin.subcategories.edit', $subcategory)); ?>" class="btn btn-sm btn-primary" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                        <form action="<?php echo e(route('admin.subcategories.destroy', $subcategory)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">No subcategories yet.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
                Showing <?php echo e($subcategories->firstItem()); ?> to <?php echo e($subcategories->lastItem()); ?> of <?php echo e($subcategories->total()); ?> entries
            </div>
            <?php echo e($subcategories->appends(request()->query())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\plantsware\resources\views/admin/products-management/subcategories.blade.php ENDPATH**/ ?>