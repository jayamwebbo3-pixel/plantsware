<?php echo $__env->make('view.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="sp_header bg-white p-3">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <ul class="list-unstyled mb-0">
                    <li class="d-inline-block font-weight-bolder"><a href="<?php echo e(route('home')); ?>" class="text-decoration-none">home</a></li>
                    <li class="d-inline-block font-weight-bolder mx-2">/</li>
                    <li class="d-inline-block font-weight-bolder"><a href="#" class="text-decoration-none">Categories</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<section class="py-4">
    <div class="container-fluid">
        <div class="row">
            <!-- Side Menu for Categories with Filters -->
            <div class="col-lg-3 col-md-4 mb-4">
                <div class="side-menu bg-white rounded shadow-sm p-3 sticky-top" style="top: 20px; z-index: 1; border: 1px solid #ddd;">
                    <h2 class="side-menu-title mb-3">Filters</h2>
                    
                    <!-- Price Range Filter -->
                    <div class="filter-section active mb-3">
                        <h3 class="filter-title d-flex justify-content-between align-items-center mb-2">
                            Price Range
                            <span class="price-range-value" id="display-price-range">₹0 - ₹5000</span>
                        </h3>
                        <div class="filter-options d-flex align-items-center">
                            <input type="range" class="form-range flex-grow-1 me-2" min="0" max="10000" step="100" id="price-max" value="5000" style="width: 100%;">
                        </div>
                    </div>
                    
                    <!-- Discount Filter -->
                    <div class="filter-section active mb-3">
                        <h3 class="filter-title d-flex justify-content-between align-items-center mb-2">Discount</h3>
                        <div class="filter-options">
                            <div class="filter-item">
                                <input type="radio" name="discount" id="discount-all" class="filter-radio" value="all" checked>
                                <label for="discount-all" class="filter-label">
                                    All Discounts
                                    <span class="filter-count">(45)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="discount" id="discount-50" class="filter-radio" value="50">
                                <label for="discount-50" class="filter-label">
                                    50% and above
                                    <span class="filter-count">(8)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="discount" id="discount-30" class="filter-radio" value="30-50">
                                <label for="discount-30" class="filter-label">
                                    30% - 50%
                                    <span class="filter-count">(12)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="discount" id="discount-10" class="filter-radio" value="10-30">
                                <label for="discount-10" class="filter-label">
                                    10% - 30%
                                    <span class="filter-count">(18)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="discount" id="discount-below10" class="filter-radio" value="below10">
                                <label for="discount-below10" class="filter-label">
                                    Below 10%
                                    <span class="filter-count">(7)</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Weight Filter -->
                    <div class="filter-section active mb-3">
                        <h3 class="filter-title d-flex justify-content-between align-items-center mb-2">Weight</h3>
                        <div class="filter-options">
                            <div class="filter-item">
                                <input type="checkbox" id="weight-100g" class="filter-checkbox" value="100g">
                                <label for="weight-100g" class="filter-label">
                                    Up to 100g
                                    <span class="filter-count">(6)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="weight-500g" class="filter-checkbox" value="500g">
                                <label for="weight-500g" class="filter-label">
                                    100g - 500g
                                    <span class="filter-count">(12)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="weight-1kg" class="filter-checkbox" value="1kg">
                                <label for="weight-1kg" class="filter-label">
                                    500g - 1kg
                                    <span class="filter-count">(15)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="weight-5kg" class="filter-checkbox" value="5kg">
                                <label for="weight-5kg" class="filter-label">
                                    1kg - 5kg
                                    <span class="filter-count">(8)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="weight-above5kg" class="filter-checkbox" value="above5kg">
                                <label for="weight-above5kg" class="filter-label">
                                    Above 5kg
                                    <span class="filter-count">(4)</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Brand Filter -->
                    <div class="filter-section active mb-3">
                        <h3 class="filter-title d-flex justify-content-between align-items-center mb-2">Brand</h3>
                        <div class="filter-options">
                            <div class="filter-item">
                                <input type="checkbox" id="brand-organic" class="filter-checkbox" value="Organic Harvest">
                                <label for="brand-organic" class="filter-label">
                                    Organic Harvest
                                    <span class="filter-count">(10)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="brand-garden" class="filter-checkbox" value="Garden Pro">
                                <label for="brand-garden" class="filter-label">
                                    Garden Pro
                                    <span class="filter-count">(8)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="brand-green" class="filter-checkbox" value="Green Thumb">
                                <label for="brand-green" class="filter-label">
                                    Green Thumb
                                    <span class="filter-count">(12)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="brand-natural" class="filter-checkbox" value="Natural Growth">
                                <label for="brand-natural" class="filter-label">
                                    Natural Growth
                                    <span class="filter-count">(6)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="brand-premium" class="filter-checkbox" value="Premium Plant">
                                <label for="brand-premium" class="filter-label">
                                    Premium Plant
                                    <span class="filter-count">(9)</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Customer Ratings -->
                    <div class="filter-section active mb-3">
                        <h3 class="filter-title d-flex justify-content-between align-items-center mb-2">Customer Ratings</h3>
                        <div class="filter-options">
                            <div class="filter-item">
                                <input type="radio" name="rating" id="rating-4" class="filter-radio" value="4">
                                <label for="rating-4" class="filter-label">
                                    <span class="stars">
                                        ★★★★☆ & above
                                    </span>
                                    <span class="filter-count">(20)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="rating" id="rating-3" class="filter-radio" value="3">
                                <label for="rating-3" class="filter-label">
                                    <span class="stars">
                                        ★★★☆☆ & above
                                    </span>
                                    <span class="filter-count">(30)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="rating" id="rating-2" class="filter-radio" value="2">
                                <label for="rating-2" class="filter-label">
                                    <span class="stars">
                                        ★★☆☆☆ & above
                                    </span>
                                    <span class="filter-count">(40)</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Availability -->
                    <div class="filter-section active mb-3">
                        <h3 class="filter-title d-flex justify-content-between align-items-center mb-2">Availability</h3>
                        <div class="filter-options">
                            <div class="filter-item">
                                <input type="checkbox" id="in-stock" class="filter-checkbox" value="in-stock" checked>
                                <label for="in-stock" class="filter-label">
                                    In Stock
                                    <span class="filter-count">(40)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="out-of-stock" class="filter-checkbox" value="out-of-stock">
                                <label for="out-of-stock" class="filter-label">
                                    Out of Stock
                                    <span class="filter-count">(5)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="fast-delivery" class="filter-checkbox" value="fast-delivery">
                                <label for="fast-delivery" class="filter-label">
                                    Fast Delivery
                                    <span class="filter-count">(25)</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Sort By -->
                    <div class="filter-section active mb-3">
                        <h3 class="filter-title d-flex justify-content-between align-items-center mb-2">Sort By</h3>
                        <div class="filter-options">
                            <div class="filter-item">
                                <input type="radio" name="sort" id="sort-popular" class="filter-radio" value="popularity" checked>
                                <label for="sort-popular" class="filter-label">Popularity</label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="sort" id="sort-price-low" class="filter-radio" value="price-low">
                                <label for="sort-price-low" class="filter-label">Price: Low to High</label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="sort" id="sort-price-high" class="filter-radio" value="price-high">
                                <label for="sort-price-high" class="filter-label">Price: High to Low</label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="sort" id="sort-new" class="filter-radio" value="newest">
                                <label for="sort-new" class="filter-label">Newest First</label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="sort" id="sort-discount" class="filter-radio" value="discount">
                                <label for="sort-discount" class="filter-label">Discount</label>
                            </div>
                            <div class="filter-item">
                                <input type="radio" name="sort" id="sort-rating" class="filter-radio" value="rating">
                                <label for="sort-rating" class="filter-label">Customer Rating</label>
                            </div>
                        </div>
                    </div>

                    <!-- Value Filter (Best Value, Premium, etc.) -->
                    <div class="filter-section active mb-3">
                        <h3 class="filter-title d-flex justify-content-between align-items-center mb-2">Value</h3>
                        <div class="filter-options">
                            <div class="filter-item">
                                <input type="checkbox" id="value-best" class="filter-checkbox" value="best">
                                <label for="value-best" class="filter-label">
                                    Best Value
                                    <span class="filter-count">(15)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="value-premium" class="filter-checkbox" value="premium">
                                <label for="value-premium" class="filter-label">
                                    Premium
                                    <span class="filter-count">(10)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="value-budget" class="filter-checkbox" value="budget">
                                <label for="value-budget" class="filter-label">
                                    Budget Friendly
                                    <span class="filter-count">(20)</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Delivery Options -->
                    <div class="filter-section active mb-3">
                        <h3 class="filter-title d-flex justify-content-between align-items-center mb-2">Delivery Options</h3>
                        <div class="filter-options">
                            <div class="filter-item">
                                <input type="checkbox" id="delivery-free" class="filter-checkbox" value="free-delivery">
                                <label for="delivery-free" class="filter-label">
                                    Free Delivery
                                    <span class="filter-count">(35)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="delivery-same-day" class="filter-checkbox" value="same-day">
                                <label for="delivery-same-day" class="filter-label">
                                    Same Day Delivery
                                    <span class="filter-count">(12)</span>
                                </label>
                            </div>
                            <div class="filter-item">
                                <input type="checkbox" id="delivery-next-day" class="filter-checkbox" value="next-day">
                                <label for="delivery-next-day" class="filter-label">
                                    Next Day Delivery
                                    <span class="filter-count">(28)</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Filter Actions -->
                    <div class="filter-actions d-flex gap-2 mt-3">
                        <button class="btn-filter btn-apply flex-fill" id="apply-filters" type="button">Apply Filters</button>
                        <button class="btn-filter btn-reset flex-fill" id="reset-filters" type="button">Reset All</button>
                    </div>

                    <!-- Active Filters Display -->
                    <div class="active-filters mt-3 d-none" id="active-filters">
                        <h4 class="mb-2">Active Filters:</h4>
                        <div class="d-flex flex-wrap gap-2" id="active-filters-list">
                            <!-- Active filters will be added here dynamically -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- Products Display Area -->
            <div class="col-lg-9 col-md-8">
                <div class="products-area">
                    <div class="products-header bg-white rounded p-3 mb-4">
                        <?php if(isset($category) && $category->image): ?>
                            <div class="category-image-banner mb-4 text-center">
                                <img src="<?php echo e(asset('storage/' . $category->image)); ?>" alt="<?php echo e($category->name); ?>" style="max-height: 300px; width: 100%; object-fit: cover; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                            </div>
                        <?php endif; ?>
                        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                            <h2 class="category-name mb-2 mb-md-0"><?php echo e(isset($category) ? $category->name : 'All Categories'); ?></h2>

                            <div class="sort-options">
                                <select id="sort-products" class="form-select">
                                    <option value="default">Sort by: Default</option>
                                    <option value="name-asc">Name: A to Z</option>
                                    <option value="name-desc">Name: Z to A</option>
                                    <option value="price-low">Price: Low to High</option>
                                    <option value="price-high">Price: High to Low</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="products-grid row g-3" id="products-container">
                        <?php if(isset($category) && isset($products)): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-4">
                                <div class="product-card">
                                    <div class="product-image-container">
                                        <a href="<?php echo e(route('product.show', $product->slug)); ?>">
                                            <?php if($product->image): ?>
                                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                                    class="product-image main-image">
                                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                                    class="product-image hover-image">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/images/product/product1.jpg')); ?>" alt="<?php echo e($product->name); ?>"
                                                    class="product-image main-image">
                                                <img src="<?php echo e(asset('assets/images/product/product1.jpg')); ?>" alt="<?php echo e($product->name); ?>"
                                                    class="product-image hover-image">
                                            <?php endif; ?>
                                            <?php if($product->sale_price && $product->sale_price > 0 && $product->sale_price < $product->price && $product->discount_percentage > 0): ?>
                                                <span class="discount-badge"><?php echo e($product->discount_percentage); ?>% OFF</span>
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="product-info">
                                        <h3 class="product-title"><?php echo e($product->name); ?></h3>
                                        <div class="product-price">
                                            <?php if($product->sale_price && $product->sale_price > 0 && $product->sale_price < $product->price): ?>
                                                <span class="original-price">₹<?php echo e(number_format($product->price, 2)); ?></span>
                                                <span class="current-price">₹<?php echo e(number_format($product->sale_price, 2)); ?></span>
                                            <?php else: ?>
                                                <span class="current-price">₹<?php echo e(number_format($product->price, 2)); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="product-actions">
                                            <button class="btn btn-primary" data-tooltip="Buy Now" type="button" onclick="window.location='<?php echo e(route('checkout.index')); ?>'">
                                                <span class="btn-text">Buy Now</span><i class="btn-icon fas fa-shopping-bag"></i>
                                            </button>
                                            <form class="add-to-cart-form d-inline-block" method="POST" action="<?php echo e(route('cart.add', $product->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-secondary" data-tooltip="Add to Cart">
                                                    <span class="btn-text">Add to Cart</span><i class="btn-icon fas fa-shopping-cart"></i>
                                                </button>
                                            </form>
                                            <form class="d-inline-block" method="POST" action="<?php echo e(route('wishlist.add', $product->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-wishlist" data-tooltip="Wishlist">
                                                    <i class="far fa-heart"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12">
                                <p class="text-center">No products found in this category.</p>
                            </div>
                            <?php endif; ?>
                            <?php if(isset($products) && method_exists($products, 'links')): ?>
                            <div class="col-12 mt-4">
                                <?php echo e($products->links()); ?>

                            </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($cat->products && $cat->products->count() > 0): ?>
                                    <?php $__currentLoopData = $cat->products->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-4">
                                        <div class="product-card">
                                            <div class="product-image-container">
                                                <a href="<?php echo e(route('product.show', $product->slug)); ?>">
                                                    <?php if($product->image): ?>
                                                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                                            class="product-image main-image">
                                                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                                            class="product-image hover-image">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('assets/images/product/product1.jpg')); ?>" alt="<?php echo e($product->name); ?>"
                                                            class="product-image main-image">
                                                        <img src="<?php echo e(asset('assets/images/product/product1.jpg')); ?>" alt="<?php echo e($product->name); ?>"
                                                            class="product-image hover-image">
                                                    <?php endif; ?>
                                                    <?php if($product->sale_price && $product->sale_price > 0 && $product->sale_price < $product->price && $product->discount_percentage > 0): ?>
                                                        <span class="discount-badge"><?php echo e($product->discount_percentage); ?>% OFF</span>
                                                    <?php endif; ?>
                                                </a>
                                            </div>
                                            <div class="product-info">
                                                <h3 class="product-title"><?php echo e($product->name); ?></h3>
                                                <div class="product-price">
                                                    <?php if($product->sale_price && $product->sale_price > 0 && $product->sale_price < $product->price): ?>
                                                        <span class="original-price">₹<?php echo e(number_format($product->price, 2)); ?></span>
                                                        <span class="current-price">₹<?php echo e(number_format($product->sale_price, 2)); ?></span>
                                                    <?php else: ?>
                                                        <span class="current-price">₹<?php echo e(number_format($product->price, 2)); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="product-actions">
                                                    <button class="btn btn-primary" data-tooltip="Buy Now" type="button" onclick="window.location='<?php echo e(route('checkout.index')); ?>'">
                                                        <span class="btn-text">Buy Now</span><i class="btn-icon fas fa-shopping-bag"></i>
                                                    </button>
                                                    <form class="add-to-cart-form d-inline-block" method="POST" action="<?php echo e(route('cart.add', $product->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-secondary" data-tooltip="Add to Cart">
                                                            <span class="btn-text">Add to Cart</span><i class="btn-icon fas fa-shopping-cart"></i>
                                                        </button>
                                                    </form>
                                                    <form class="d-inline-block" method="POST" action="<?php echo e(route('wishlist.add', $product->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-wishlist" data-tooltip="Wishlist">
                                                            <i class="far fa-heart"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12">
                                <p class="text-center">No categories or products found.</p>
                            </div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <!-- Demo products for display if nothing found (optional, comment out for production) -->
                        <!--
                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-4">
                            <div class="product-card">
                                <div class="product-image-container">
                                    <a href="#">
                                        <img src="<?php echo e(asset('assets/images/product/product2.jpg')); ?>" alt="vermiculite" class="product-image main-image">
                                        <img src="<?php echo e(asset('assets/images/product/product2.jpg')); ?>" alt="vermiculite" class="product-image hover-image">
                                    </a>
                                </div>
                                <div class="product-info">
                                    <h3 class="product-title">Vermiculite</h3>
                                    <div class="product-price"><span class="current-price">₹699.00</span></div>
                                    <div class="product-actions">
                                        <button class="btn btn-primary" data-tooltip="Buy Now"><span class="btn-text">Buy Now</span><i class="btn-icon fas fa-shopping-bag"></i></button>
                                        <button class="btn btn-secondary" data-tooltip="Add to Cart"><span class="btn-text">Add to Cart</span><i class="btn-icon fas fa-shopping-cart"></i></button>
                                        <button class="btn btn-wishlist" data-tooltip="Wishlist"><i class="far fa-heart"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        -->
                        <!-- Remove static demo product cards from final code -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Price Range Display Sync
    const priceInput = document.getElementById('price-max');
    const displayPriceRange = document.getElementById('display-price-range');
    let minPrice = 0;
    priceInput.addEventListener('input', function() {
        displayPriceRange.textContent = `₹${minPrice} - ₹${priceInput.value}`;
    });

    // Filter functionality
    const applyFiltersBtn = document.getElementById('apply-filters');
    const resetFiltersBtn = document.getElementById('reset-filters');
    const checkboxes = document.querySelectorAll('.filter-checkbox');
    const activeFiltersContainer = document.getElementById('active-filters');
    const activeFiltersList = document.getElementById('active-filters-list');

    // Apply filters
    applyFiltersBtn.addEventListener('click', function() {
        const selectedFilters = [];
        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const label = checkbox.nextElementSibling.textContent.trim();
                selectedFilters.push(label.replace(/\s+\(\d+\)$/, ''));
            }
        });

        // Discount
        const discount = document.querySelector('input[name="discount"]:checked');
        if (discount) {
            const discountLabel = discount.nextElementSibling.textContent.trim();
            selectedFilters.push(discountLabel.replace(/\s+\(\d+\)$/, ''));
        }

        // Ratings
        const rating = document.querySelector('input[name="rating"]:checked');
        if (rating) {
            const ratingLabel = rating.nextElementSibling.textContent.trim();
            selectedFilters.push(ratingLabel.replace(/\s+\(\d+\)$/, ''));
        }

        // Sort
        const sort = document.querySelector('input[name="sort"]:checked');
        if (sort) {
            const sortLabel = sort.nextElementSibling.textContent.trim();
            selectedFilters.push('Sort: ' + sortLabel);
        }

        // Price Range
        selectedFilters.push(displayPriceRange.textContent);

        if (selectedFilters.length > 0) {
            // Optionally update UI
            activeFiltersContainer.classList.remove('d-none');
            activeFiltersList.innerHTML = '';
            selectedFilters.forEach(fltr => {
                const span = document.createElement('span');
                span.className = 'badge bg-primary text-white';
                span.textContent = fltr;
                activeFiltersList.appendChild(span);
            });
            console.log('Applied filters:', selectedFilters);
            alert('Filters applied: ' + selectedFilters.join(', '));
        } else {
            alert('Please select at least one filter');
        }
    });

    // Reset filters
    resetFiltersBtn.addEventListener('click', function() {
        checkboxes.forEach(checkbox => {
            checkbox.checked = false;
        });

        // Reset radio buttons to default states
        let discountDefault = document.getElementById('discount-all');
        if (discountDefault) discountDefault.checked = true;
        let sortDefault = document.getElementById('sort-popular');
        if (sortDefault) sortDefault.checked = true;

        let ratingRadios = document.querySelectorAll('input[name="rating"]');
        ratingRadios.forEach(radio => radio.checked = false);

        // Reset price range
        priceInput.value = 5000;
        displayPriceRange.textContent = `₹0 - ₹5000`;

        // Hide active filters
        activeFiltersContainer.classList.add('d-none');
        activeFiltersList.innerHTML = '';
        console.log('Filters reset');
    });

    // Product actions functionality
    document.querySelectorAll('.btn-secondary').forEach(button => {
        button.addEventListener('click', function() {
            const product = this.closest('.product-card').querySelector('.product-title').textContent;
            alert(product + ' added to cart!');
        });
    });

    document.querySelectorAll('.btn-primary').forEach(button => {
        button.addEventListener('click', function() {
            const product = this.closest('.product-card').querySelector('.product-title').textContent;
            alert('Buying now: ' + product);
        });
    });

    document.querySelectorAll('.btn-wishlist').forEach(button => {
        button.addEventListener('click', function() {
            const icon = this.querySelector('i');
            const product = this.closest('.product-card').querySelector('.product-title').textContent;
            if (icon.classList.contains('far')) {
                icon.classList.remove('far');
                icon.classList.add('fas');
                icon.style.color = '#e53e3e';
                alert(product + ' added to wishlist!');
            } else {
                icon.classList.remove('fas');
                icon.classList.add('far');
                icon.style.color = '';
                alert(product + ' removed from wishlist!');
            }
        });
    });

    // Sort functionality
    document.getElementById('sort-products').addEventListener('change', function() {
        // Add actual sorting logic as necessary.
        console.log('Sorting by: ' + this.value);
    });

    // Collapsible filter sections
    document.querySelectorAll('.filter-title').forEach(title => {
        title.addEventListener('click', function(e) {
            // Prevent collapse if filter section has no options (title only, not desired here)
            if(this.parentElement.querySelector('.filter-options')) {
                this.parentElement.classList.toggle('active');
            }
        });
    });
});
</script>

<?php echo $__env->make('view.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\plantsware\resources\views/view/productcategory.blade.php ENDPATH**/ ?>