<?php $__env->startSection('title', 'Orders Management'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .order-status-btn {
        border: 1.5px solid transparent;
        background-color: #fff;
        color: #6c757d;
        font-weight: 500;
        border-radius: 6px;
        margin-right: 6px;
        margin-bottom: 6px;
        transition: all 0.2s;
        box-shadow: none;
    }
    .order-status-btn.active, .order-status-btn:focus {
        color: #fff !important;
    }
    .order-status-btn.status-all {
        border-color: #adb5bd;
        color: #495057;
        background: #adb5bd;
    }
    .order-status-btn.status-processing {
        border-color: #a48cff;
        color: #7e57c2;
        background: #f6f0ff;
    }
    .order-status-btn.status-processing.active,
    .order-status-btn.status-processing:focus {
        background: #a48cff !important;
        color: #fff !important;
        border-color: #a48cff !important;
    }

    .order-status-btn.status-shipped {
        border-color: #42a5f5;
        color: #1976d2;
        background: #e3f2fd;
    }
    .order-status-btn.status-shipped.active,
    .order-status-btn.status-shipped:focus {
        background: #42a5f5 !important;
        color: #fff !important;
        border-color: #42a5f5 !important;
    }

    .order-status-btn.status-delivered {
        border-color: #66bb6a;
        color: #388e3c;
        background: #e8f5e9;
    }
    .order-status-btn.status-delivered.active,
    .order-status-btn.status-delivered:focus {
        background: #66bb6a !important;
        color: #fff !important;
        border-color: #66bb6a !important;
    }

    .order-status-btn.status-cancelled {
        border-color: #ef9a9a;
        color: #e53935;
        background: #ffebee;
    }
    .order-status-btn.status-cancelled.active,
    .order-status-btn.status-cancelled:focus {
        background: #e57373 !important;
        color: #fff !important;
        border-color: #e57373 !important;
    }

    .order-status-btn.status-returned {
        border-color: #ffb74d;
        color: #ffa000;
        background: #fff8e1;
    }
    .order-status-btn.status-returned.active,
    .order-status-btn.status-returned:focus {
        background: #ffb74d !important;
        color: #fff !important;
        border-color: #ffb74d !important;
    }
</style>
<div class="container-fluid">
    <!-- Top Stats Bar -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-3">
                    <div class="row text-center">
                        <div class="col-lg-2 col-md-4 col-6 mb-3">
                            <h4 class="mb-0"><?php echo e($stats['total'] ?? 0); ?></h4>
                            <small class="text-muted">Total Orders</small>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6 mb-3">
                            <h4 class="mb-0 text-warning"><?php echo e($stats['pending'] ?? 0); ?></h4>
                            <small class="text-muted">Pending</small>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6 mb-3">
                            <h4 class="mb-0 text-primary"><?php echo e($stats['shipped'] ?? 0); ?></h4>
                            <small class="text-muted">Shipped</small>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6 mb-3">
                            <h4 class="mb-0 text-info"><?php echo e($stats['processing'] ?? 0); ?></h4>
                            <small class="text-muted">Processing</small>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6 mb-3">
                            <h4 class="mb-0 text-success"><?php echo e($stats['delivered'] ?? 0); ?></h4>
                            <small class="text-muted">Delivered</small>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6 mb-3">
                            <h4 class="mb-0 text-danger"><?php echo e($stats['cancelled'] ?? 0); ?></h4>
                            <small class="text-muted">Cancelled</small>
                        </div>
                    </div>
                    <div class="row text-center mt-2">
                        <div class="col-lg-2 col-md-4 col-6 mb-3">
                            <h4 class="mb-0 text-secondary"><?php echo e($stats['returned'] ?? 0); ?></h4>
                            <small class="text-muted">Returned</small>
                        </div>
                        <div class="col-lg-10 col-md-8 col-6 mb-3 text-start small text-muted d-flex align-items-center">
                            <span>
                                Returned Requested: <?php echo e($stats['return_requested'] ?? 0); ?> |
                                Returned Approved: <?php echo e($stats['return_approved'] ?? 0); ?> |
                                Returned Rejected: <?php echo e($stats['return_rejected'] ?? 0); ?>

                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Card -->
    <div class="card shadow-sm">
        <div class="card-header bg-white border-0 py-3">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request('customized') ? '' : 'active'); ?>" href="<?php echo e(route('admin.orders.index', array_merge(request()->except('customized')))); ?>">
                        All Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request('customized') ? 'active' : ''); ?>" href="<?php echo e(route('admin.orders.index', array_merge(request()->all(), ['customized' => 1]))); ?>">
                        Customized Orders
                    </a>
                </li>
            </ul>
        </div>

        <div class="card-body">
            <!-- Action Buttons & Filters -->
            <div class="row mb-3 align-items-center">
                <div class="col-md-3">
                    <!--
                        In a real implementation, this button should submit a form to trigger a payment status update,
                        likely opening a modal to select the order(s) and new payment status.
                    -->
                    <button type="button" class="btn btn-warning btn-sm" disabled title="Select orders to change payment status">Change Payment Status</button>
                </div>
                <div class="col-md-6 text-center">
                    
                    <div class="d-inline-flex flex-wrap" role="group">
                        <?php
                            $statuses = [
                                '' => ['label' => 'All', 'class' => 'status-all'],
                                'processing' => ['label' => 'Processing', 'class' => 'status-processing'],
                                'shipped' => ['label' => 'Shipped', 'class' => 'status-shipped'],
                                'delivered' => ['label' => 'Delivered', 'class' => 'status-delivered'],
                                'cancelled' => ['label' => 'Cancelled', 'class' => 'status-cancelled'],
                                'returned' => ['label' => 'Returned', 'class' => 'status-returned'],
                            ];
                            $currentStatus = request('status') ?: '';
                        ?>
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('admin.orders.index', array_merge(request()->except('page'), $code ? ['status' => $code] : ['status' => null]))); ?>"
                               class="order-status-btn btn btn-sm <?php echo e($meta['class']); ?><?php echo e($currentStatus === $code ? ' active' : ''); ?>">
                                <?php echo e($meta['label']); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-3 text-end">
                    <form method="GET" class="d-inline">
                        <?php $__currentLoopData = request()->except(['per_page', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($val); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <small class="me-2">Show</small>
                        <select name="per_page" onchange="this.form.submit()" class="form-select form-select-sm d-inline w-auto">
                            <option value="10" <?php echo e(request('per_page', 10) == 10 ? 'selected' : ''); ?>>10</option>
                            <option value="25" <?php echo e(request('per_page') == 25 ? 'selected' : ''); ?>>25</option>
                            <option value="50" <?php echo e(request('per_page') == 50 ? 'selected' : ''); ?>>50</option>
                            <option value="100" <?php echo e(request('per_page') == 100 ? 'selected' : ''); ?>>100</option>
                        </select>
                    </form>
                </div>
            </div>

            <!-- Search -->
            <div class="row mb-3">
                <div class="col-md-4 offset-md-8">
                    <form method="GET">
                        <?php $__currentLoopData = request()->except(['search', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($val); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="input-group">
                            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search..." value="<?php echo e(request('search')); ?>">
                            <button class="btn btn-outline-secondary btn-sm" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Orders Table -->
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>SL NO</th>
                            <th>ORDER ID</th>
                            <th>USER NAME</th>
                            <th>MOBILE NO</th>
                            <th>ADDRESS</th>
                            <th>PAYMENT STATUS</th>
                            <th>ORDER STATUS</th>
                            <th>TOTAL AMOUNT</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(($orders->currentPage() - 1) * $orders->perPage() + $loop->iteration); ?></td>
                            <td><strong><?php echo e($order->order_number); ?></strong></td>
                            <td><?php echo e($order->user?->name ?? 'Guest'); ?></td>
                            <td>
                                <?php echo e($order->shipping_address['phone'] ?? ($order->user?->phone ?? 'N/A')); ?>

                            </td>
                            <td class="small">
                                <?php echo e($order->shipping_address['address'] ?? 'N/A'); ?>

                                <?php if(!empty($order->shipping_address['address'])): ?><br><?php endif; ?>
                                <?php echo e($order->shipping_address['city'] ?? ''); ?>

                                <?php if(!empty($order->shipping_address['city'])): ?>,<?php endif; ?>
                                <?php echo e($order->shipping_address['state'] ?? ''); ?>

                                <?php if(!empty($order->shipping_address['pincode'])): ?> - <?php echo e($order->shipping_address['pincode']); ?><?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $paymentStatus = $order->payment_status;
                                    $paymentBadge = [
                                        'paid' => 'bg-success',
                                        'pending' => 'bg-warning text-dark',
                                        'failed' => 'bg-danger',
                                        'refunded' => 'bg-info text-dark'
                                    ][$paymentStatus] ?? 'bg-secondary';
                                ?>
                                <span class="badge <?php echo e($paymentBadge); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $paymentStatus))); ?>

                                </span>
                            </td>
                            <td>
                                <?php
                                    if (method_exists($order, 'getStatusBadgeClass')) {
                                        $badgeClass = $order->getStatusBadgeClass();
                                    } else {
                                        $statusColor = [
                                            'pending' => 'bg-warning text-dark',
                                            'processing' => 'bg-info text-dark',
                                            'shipped' => 'bg-primary',
                                            'delivered' => 'bg-success',
                                            'cancelled' => 'bg-danger',
                                            'returned' => 'bg-secondary'
                                        ][$order->status] ?? 'bg-secondary';
                                        $badgeClass = $statusColor;
                                    }
                                ?>
                                <span class="badge <?php echo e($badgeClass); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?>

                                </span>
                            </td>
                            <td>₹<?php echo e(number_format($order->total, 2)); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="btn btn-sm btn-info" title="View Order">
                                    <i class="fas fa-eye"></i> View
                                </a>
                                <a href="#" class="btn btn-sm btn-success" title="View Invoice" disabled>
                                    <i class="fas fa-file-invoice"></i> Invoice
                                </a>
                                <?php if($order->status == 'processing'): ?>
                                    <a href="#" class="btn btn-sm btn-primary" disabled title="Ship order (not implemented)">Ship</a>
                                <?php endif; ?>
                                <?php if(in_array($order->status, ['pending', 'processing'])): ?>
                                    <a href="#" class="btn btn-sm btn-danger" disabled title="Cancel order (not implemented)">Cancel</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center py-5 text-muted">
                                No orders found.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-between align-items-center mt-4">
                <div class="text-muted small">
                    Showing <?php echo e($orders->firstItem() ?? 0); ?> to <?php echo e($orders->lastItem() ?? 0); ?> of <?php echo e($orders->total()); ?> entries
                </div>
                <?php echo e($orders->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\plantsware\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>