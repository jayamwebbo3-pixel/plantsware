   

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">All Blogs</h3>

                        <div class="card-tools">
                            <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-primary btn-sm">
                                <i class="fas fa-plus"></i> Create New Blog
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <form method="GET" action="<?php echo e(route('admin.blogs.index')); ?>" class="mb-4">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" 
                                       placeholder="Search by title..." 
                                       value="<?php echo e(request('search')); ?>">
                                <button class="btn btn-primary" type="submit">Search</button>
                            </div>
                        </form>

                        <table class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <!-- <th>Category</th> -->
                                    <th>Author</th>
                                    <th>Published</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($blog->title); ?></td>
                                        <!-- <td><?php echo e($blog->blogCategory?->name ?? '—'); ?></td> -->
                                        <td><?php echo e($blog->author_name ?? 'Admin'); ?></td>
                                        <td><?php echo e($blog->published_at?->format('d M Y') ?? 'Draft'); ?></td>
                                        <td>
                                            <?php if($blog->is_active): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.blogs.show', $blog)); ?>" class="btn btn-info btn-sm">View</a>
                                            <a href="<?php echo e(route('admin.blogs.edit', $blog)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                            
                                            <form action="<?php echo e(route('admin.blogs.destroy', $blog)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" 
                                                        onclick="return confirm('Are you sure?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No blogs found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <?php echo e($blogs->links()); ?>  
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\plantsware\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>