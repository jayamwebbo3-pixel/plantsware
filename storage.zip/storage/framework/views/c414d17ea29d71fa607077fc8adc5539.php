<?php $__env->startSection('title', 'Product Management - Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Categories</h2>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add New Category
    </a>
</div>

<div class="card">
    <div class="card-body">
        <!-- Search & Filters -->
        <div class="row mb-3">
            <div class="col-md-6">
                <form action="<?php echo e(route('admin.products.management')); ?>" method="GET">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search categories..." value="<?php echo e(request('search')); ?>">
                        <button class="btn btn-outline-secondary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                        
                        <input type="hidden" name="per_page" value="<?php echo e(request('per_page', 20)); ?>">
                        <input type="hidden" name="sort" value="<?php echo e(request('sort', 'sort_order')); ?>">
                        <input type="hidden" name="direction" value="<?php echo e(request('direction', 'asc')); ?>">
                    </div>
                </form>
            </div>
            <div class="col-md-6 text-end">
                <form action="<?php echo e(route('admin.products.management')); ?>" method="GET" class="d-inline">
                    <label class="me-2">Show</label>
                    <select name="per_page" onchange="this.form.submit()" class="form-select d-inline w-auto">
                        <option value="10" <?php echo e(request('per_page', 20) == 10 ? 'selected' : ''); ?>>10</option>
                        <option value="25" <?php echo e(request('per_page', 20) == 25 ? 'selected' : ''); ?>>25</option>
                        <option value="50" <?php echo e(request('per_page', 20) == 50 ? 'selected' : ''); ?>>50</option>
                        <option value="100" <?php echo e(request('per_page', 20) == 100 ? 'selected' : ''); ?>>100</option>
                    </select>
                    <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                    <input type="hidden" name="sort" value="<?php echo e(request('sort', 'sort_order')); ?>">
                    <input type="hidden" name="direction" value="<?php echo e(request('direction', 'asc')); ?>">
                </form>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Image</th>
                        <th>
                            <a href="<?php echo e(route('admin.products.management', [
                                    'sort' => 'name',
                                    'direction' => request('sort') == 'name' && request('direction') == 'asc' ? 'desc' : 'asc',
                                    'search' => request('search'),
                                    'per_page' => request('per_page', 20)
                                ])); ?>" class="text-dark text-decoration-none">
                                Name
                                <?php if(request('sort') == 'name'): ?>
                                    <i class="fas fa-sort-<?php echo e(request('direction') == 'asc' ? 'up' : 'down'); ?> ms-1"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>Badge</th>
                        <th>
                            <a href="<?php echo e(route('admin.products.management', [
                                    'sort' => 'sort_order',
                                    'direction' => request('sort') == 'sort_order' && request('direction') == 'asc' ? 'desc' : 'asc',
                                    'search' => request('search'),
                                    'per_page' => request('per_page', 20)
                                ])); ?>" class="text-dark text-decoration-none">
                                Sort Order
                                <?php if(request('sort') == 'sort_order'): ?>
                                    <i class="fas fa-sort-<?php echo e(request('direction') == 'asc' ? 'up' : 'down'); ?> ms-1"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($category->image): ?>
                                <img src="<?php echo e(asset('storage/' . $category->image)); ?>" alt="<?php echo e($category->name); ?>" style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px;">
                            <?php else: ?>
                                <div class="bg-light border d-flex align-items-center justify-content-center" style="width: 60px; height: 60px; border-radius: 8px;">
                                    <i class="fas fa-image text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo e($category->name); ?></strong></td>
                        <td>
                            <?php if($category->badge_type): ?>
                                <span class="badge bg-info"><?php echo e(ucfirst($category->badge_type)); ?></span>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($category->sort_order ?? 0); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.categories.subcategories', $category)); ?>" class="btn btn-sm btn-outline-primary">
                                View Subcategories →
                            </a>
                            <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn btn-sm btn-primary" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this category?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4">No categories found. <a href="<?php echo e(route('admin.categories.create')); ?>">Create one now</a></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
                Showing <?php echo e($categories->firstItem()); ?> to <?php echo e($categories->lastItem()); ?> of <?php echo e($categories->total()); ?> entries
            </div>
            <?php echo e($categories->appends(request()->query())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\plantsware\resources\views/admin/products-management/categories.blade.php ENDPATH**/ ?>